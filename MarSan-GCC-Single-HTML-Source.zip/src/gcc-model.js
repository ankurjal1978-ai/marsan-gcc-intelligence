// Internal, provisional planning coefficients. Replace only after MarSan Finance signs off.
const baseCosts = [42000, 55000, 43000, 24000, 31000, 34000, 28000];
const conservativeCosts = [55000, 72000, 56000, 32000, 40000, 44000, 36000];
const upsideCosts = [40000, 52000, 41000, 23000, 30000, 33000, 27000];
const baselineBands = [0, 75000, 115000, 155000, 200000];
export function calculate(a) {
    const readiness = [7, 14, 23, 30, 35][a.stage] + (a.objectives.includes(6) ? 4 : 20)
        + (a.team < 25 ? 5 : a.team < 50 ? 8 : a.team < 100 ? 11 : 15)
        + (a.functions.length <= 2 ? 15 : a.functions.length <= 4 ? 11 : 7)
        + [3, 8, 12, 15][a.timeline];
    const band = readiness < 40 ? 'Explore the foundations' : readiness < 60 ? 'Shape the business case' : readiness < 80 ? 'Develop the operating plan' : 'Consider detailed feasibility';
    const model = a.team < 50 || a.stage < 2 ? 'Phased managed launch' : a.team >= 150 && a.stage >= 3 && a.timeline >= 2 ? 'Evaluate a captive GCC' : 'Build–Operate–Transfer';
    const annualBaseline = baselineBands[a.baselineCost] * a.team;
    const mean = (costs) => a.functions.reduce((sum, f) => sum + costs[f], 0) / a.functions.length;
    const overhead = Math.max(60000, a.team * 3000);
    const conservative = annualBaseline - a.team * mean(conservativeCosts) - overhead;
    const base = annualBaseline - a.team * mean(baseCosts) - overhead;
    const upside = annualBaseline - a.team * mean(upsideCosts) - overhead;
    return {
        readiness, band, model,
        savings: a.baselineCost === 0 ? null : {
            low: Math.round(conservative), base: Math.round(base), high: Math.round(upside),
            currentAnnual: Math.round(annualBaseline), indiaAnnual: Math.round(annualBaseline - base),
        },
        note: a.baselineCost === 0 ? 'Add your current fully loaded cost band to see a savings illustration.' : 'Directional planning estimate. Validate role mix, location, tax and transition costs before using this in a business case.',
        modelVersion: 'planning-2026-10-13-v1',
    };
}
export function validAnswers(value) {
    if (!value || typeof value !== 'object')
        return false;
    const a = value;
    const one = (n, max) => Number.isInteger(n) && n >= 0 && n <= max;
    const many = (v, max, limit) => Array.isArray(v) && v.length >= 1 && v.length <= limit && new Set(v).size === v.length && v.every(n => one(n, max));
    if (!one(a.size, 4) || !many(a.objectives, 6, 3) || !one(a.stage, 4) || !many(a.functions, 6, 7) || !one(a.timeline, 3) || !one(a.baselineCost, 4))
        return false;
    if (!Number.isInteger(a.team) || a.team < 10 || a.team > 500)
        return false;
    return !(a.objectives.includes(6) && a.objectives.length !== 1);
}
const blockedDomains = ['gmail.com', 'googlemail.com', 'yahoo.com', 'yahoo.co.in', 'hotmail.com', 'outlook.com', 'outlook.in', 'live.com', 'msn.com', 'aol.com', 'icloud.com', 'me.com', 'mac.com', 'proton.me', 'protonmail.com', 'mail.com', 'gmx.com', 'rediffmail.com', 'yandex.com', 'zoho.com', 'fastmail.com', 'hey.com', 'tuta.com', 'mailinator.com', 'yopmail.com', 'tempmail.com', 'guerrillamail.com', '10minutemail.com'];
export function validWorkEmail(input) {
    if (typeof input !== 'string' || input.length > 254)
        return null;
    const email = input.trim().toLowerCase();
    if (!/^[^\s@]{1,64}@[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?\.[a-z]{2,63}$/.test(email))
        return null;
    const domain = email.split('@')[1];
    return blockedDomains.some(d => domain === d || domain.endsWith('.' + d)) ? null : email;
}
