import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../src/index.js';

const answers = { size: 2, objectives: [0, 1, 2], team: 50, stage: 2, functions: [0, 2], timeline: 1, baselineCost: 2 };
const origin = 'https://gcc.example.com';
function request(body) {
  return new Request(`${origin}/api/leads`, { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
}

test('saves a valid lead before returning results', async () => {
  let saved = false;
  const env = { DB: { prepare() { return { bind(...values) { assert.equal(values[2], 'alex@example.org'); return { async run() { saved = true; } }; } }; } } };
  const response = await worker.fetch(request({ email: 'Alex@example.org', name: 'Alex Smith', company: 'Example Corp', answers }), env);
  assert.equal(response.status, 201);
  assert.equal(saved, true);
  assert.equal((await response.json()).result.modelVersion, 'planning-2026-10-13-v1');
});

test('rejects a personal email and a fourth objective', async () => {
  const env = { DB: { prepare() { throw new Error('should not save'); } } };
  assert.equal((await worker.fetch(request({ email: 'alex@gmail.com', name: 'Alex', company: 'Example', answers }), env)).status, 400);
  assert.equal((await worker.fetch(request({ email: 'alex@example.org', name: 'Alex', company: 'Example', answers: { ...answers, objectives: [0, 1, 2, 3] } }), env)).status, 400);
});

test('does not reveal a result if storage fails', async () => {
  const env = { DB: { prepare() { return { bind() { return { async run() { throw new Error('database unavailable'); } }; } }; } } };
  const response = await worker.fetch(request({ email: 'alex@example.org', name: 'Alex Smith', company: 'Example Corp', answers }), env);
  assert.equal(response.status, 503);
  assert.equal((await response.json()).result, undefined);
});
