import { calculate, validAnswers, validWorkEmail } from './gcc-model.js';

const json = (value, status = 200) => new Response(JSON.stringify(value), {
  status,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'private, no-store' },
});
const clean = (value, max) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const safeAttribution = value => {
  const text = clean(value, 80);
  return /^[a-zA-Z0-9 _.-]*$/.test(text) ? text : '';
};

async function saveAssessment(request, env) {
  const url = new URL(request.url);
  if (request.headers.get('origin') !== url.origin) return json({ error: 'Request origin is not allowed.' }, 403);
  if (Number(request.headers.get('content-length') || 0) > 12000) return json({ error: 'Request is too large.' }, 413);
  let body;
  try { body = await request.json(); } catch { return json({ error: 'Invalid request.' }, 400); }
  const email = validWorkEmail(body.email);
  if (!email) return json({ error: 'Enter a valid company email address.' }, 400);
  const name = clean(body.name, 100);
  const company = clean(body.company, 150);
  const role = clean(body.role, 100);
  if (name.length < 2 || company.length < 2 || !validAnswers(body.answers)) {
    return json({ error: 'Complete the required fields and assessment.' }, 400);
  }
  if (body.website) return json({ error: 'Unable to accept this request.' }, 400);
  if (!env.DB) return json({ error: 'The assessment is temporarily unavailable. Please try again later.' }, 503);

  const result = calculate(body.answers);
  const id = crypto.randomUUID();
  const attribution = body.attribution && typeof body.attribution === 'object' ? body.attribution : {};
  try {
    await env.DB.prepare(`INSERT INTO gcc_leads (
      id, created_at, work_email, email_domain, full_name, company, role,
      advisor_requested, marketing_consent, consent_notice_version, answers_json,
      source, medium, campaign, landing_page, readiness_score, result_json, model_version
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(
        id, new Date().toISOString(), email, email.split('@')[1], name, company, role || null,
        body.advisorRequested === true ? 1 : 0, body.marketingConsent === true ? 1 : 0,
        '2026-10-13-v1', JSON.stringify(body.answers),
        safeAttribution(attribution.source), safeAttribution(attribution.medium),
        safeAttribution(attribution.campaign), clean(attribution.landingPage, 200),
        result.readiness, JSON.stringify(result), result.modelVersion,
      ).run();
  } catch {
    return json({ error: 'We could not save your assessment. Please try again.' }, 503);
  }
  return json({ leadId: id, result }, 201);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/leads') {
      if (request.method !== 'POST') return json({ error: 'Method not allowed.' }, 405);
      return saveAssessment(request, env);
    }
    if (url.pathname === '/') return Response.redirect(`${url.origin}/calculator.html`, 302);
    return env.ASSETS.fetch(request);
  },
};
